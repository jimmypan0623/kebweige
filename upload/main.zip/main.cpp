#include <iostream>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <iomanip>
using namespace std;

int main(){
    char play;
    //亂數產生中獎號碼
    srand((unsigned)time(NULL));
    int W=rand()%10000;
    int M1,M2,M3,M4,M5;//各種玩法投注數
    int Guess1,Guess2;//各種玩法投注號碼
    int A,B,C,D;//組彩排序用變數
    int moneywin=0,moneywin1=0,moneywin2=0,moneywin3=0,moneywin4=0,moneywin5=0;//中獎金額
    int moneybet=0;//總投注金額
    int a=W/1000,b=W%1000/100,c=W%100/10,d=W%10;
    int i=1;//控制跳出迴圈變數
    int r=0,R=0;//判斷組彩號碼重複樹的變數
    //
    int w=a,x=b,y=c,z=d,tmpmin=99,tmpmax=-1,kb=0,sb=0,vpm=0,TTL;
    /*求出開獎號碼四位數字中最小值*/
    if (tmpmin>w)
        tmpmin=w;
    if (tmpmin>x)
        tmpmin=x;
    if (tmpmin>y)
        tmpmin=y;
    if (tmpmin>z)
        tmpmin=z;
    w=tmpmin;
    /*求出開獎號碼四位數字中最大值*/
    if(tmpmax<a){
        tmpmax=a;
    }
    if(tmpmax<b){
        tmpmax=b;
    }
    if(tmpmax<c){
        tmpmax=c;
    }
    if(tmpmax<d){
        tmpmax=d;
    }
    z=tmpmax;
    /*求出與最小值相同者有幾個含最小值自己本身*/
    if (a==tmpmin)
        sb++;
    if (b==tmpmin)
        sb++;
    if (c==tmpmin)
        sb++;
    if (d==tmpmin)
        sb++;
    /*求出與最大值相同者有幾個含最大值自己本身*/
    if (a==tmpmax)
        kb++;
    if (b==tmpmax)
        kb++;
    if (c==tmpmax)
        kb++;
    if (d==tmpmax)
        kb++;
    /*利用 w,x,y,z 四個變數從左到右由小到大排列依序分別存入此四個變數中*/
    if(sb==1 && kb==1){     //如果都沒有數字重複
        x=99;            //放一大的數值好比較交換
           if(a!= tmpmin && a!= tmpmax){
          x=a;
        }
          if(b!= tmpmin && b!= tmpmax){
              if(b<x){
              vpm=x;
              x=b;
              y=vpm;
            }else{
                 if (b==x)
                     r=1;                 //12組彩
                 y=b;
            }
        }
        if(c!= tmpmin && c!= tmpmax){
              if(c<x){
              vpm=x;
              x=c;
              y=vpm;
            }else{
                 if (c==x)
                    r=1;                //12組彩
                 y=c;
            }
        }
        if(d!= tmpmin && d!= tmpmax){
              if(d<x){
              vpm=x;
              x=d;
              y=vpm;
            }else{
                 if (d==x)
                     r=1;             //12組彩
                 y=d;
            }
        }
    }else{       //如果有數字重複
         if (sb>=3){
             x=tmpmin;
             y=tmpmin;
             r=3;                     // 4 組彩
         }else{
             if (sb==2){
                x=tmpmin;
                r=1;
                if(a!= tmpmin && a!= tmpmax)
                  y=a;
                if(b!= tmpmin && b!= tmpmax)
                  y=b;
                if(c!= tmpmin && c!= tmpmax)
                  y=c;
                if(d!= tmpmin && d!= tmpmax)
                  y=d;
             }
         }
         if (kb==2){
             y=tmpmax;
             r++;                                 //如果 r=2 則為 6 組彩  r=1則為 12組彩
             if(a!= tmpmin && a!= tmpmax)
                x=a;
            if(b!= tmpmin && b!= tmpmax)
                x=b;
            if(c!= tmpmin && c!= tmpmax)
                x=c;
            if(d!= tmpmin && d!= tmpmax)
                x=d;
         }else{
             if(kb==3){
               x=tmpmax;
              y=tmpmax;
              r=3;               // 4 組彩
             }
         }
    }
    int ttl=w*1000+x*100+y*10+z;//將開獎號碼轉換成一個各位數字由小排到大的數
    while(i!=2){
        cout << "請選擇玩法(正彩請按1;組彩請按2;停止下注請按3):";//玩法選擇：正彩或組彩
        cin >> play;
        switch(play){
            case'1'://正彩下注
                do{
                    cout << "請輸入投注號碼（0~9999):";
                    cin >> Guess1;
                    if(Guess1<0||Guess1>9999){
                        cout << "投注號碼必須在0到9999之間！";
                    }
                }while(Guess1<0||Guess1>9999);//讓使用者輸入投注號碼
                do{
                    cout << "請輸入投注倍數（每注25元;上限為600注）：";
                    cin >> M1;
                    if(M1>600||M1<0){
                        cout << "注數上限為600注！" <<endl;
                    }
                }while(M1>600||M1<0);//讓使用者輸入投注倍數
                moneybet+=M1*25;//累積投注金額
                //計算中獎金額
                if(Guess1==W){
                    moneywin1+=5000*25*M1;
                }
                break;
            case'2'://組彩下注
                //讓使用者輸入投注號碼
                do{
                    cout << "請輸入投注號碼（0~9999):";
                    cin >> Guess2;
                    w=Guess2/1000;
                    x=Guess2%1000/100;
                    y=Guess2%100/10;
                    z=Guess2%10;
                    if(Guess2<0||Guess2>9999){
                        cout << "投注號碼必須在0到9999之間！" <<endl;
                    }
                    if(w==x&&x==y&&y==z){
                        cout << "組彩不接受四個數字相同的投注!" <<endl;
                    }
                }while(Guess2<0||Guess2>9999||(w==x&&x==y&&y==z));
                //開始轉換投注號碼
                A=w;
                B=x;
                C=y;
                D=z;
                tmpmin=99;
                tmpmax=-1;
                kb=0;
                sb=0;
                vpm=0;
                /*求出輸入號碼號碼四位數字中最小值*/
                if (tmpmin>A)
                    tmpmin=A;
                if (tmpmin>B)
                    tmpmin=B;
                if (tmpmin>C)
                    tmpmin=C;
                if (tmpmin>D)
                    tmpmin=D;
                w=tmpmin;
                /*求出輸入號碼四位數字中最大值*/
                if(tmpmax<A){
                    tmpmax=A;
                }
                if(tmpmax<B){
                    tmpmax=B;
                }
                if(tmpmax<C){
                    tmpmax=C;
                }
                if(tmpmax<D){
                    tmpmax=D;
                }
                z=tmpmax;
                /*求出與最小值相同者有幾個含最小值自己本身*/
                if (A==tmpmin)
                    sb++;
                if (B==tmpmin)
                    sb++;
                if (C==tmpmin)
                    sb++;
                if (D==tmpmin)
                    sb++;
                /*求出與最大值相同者有幾個含最大值自己本身*/
                if (A==tmpmax)
                    kb++;
                if (B==tmpmax)
                    kb++;
                if (C==tmpmax)
                    kb++;
                if (D==tmpmax)
                    kb++;
                /*利用 w,x,y,z 四個變數從左到右由小到大排列依序分別存入此四個變數中*/
                   if(sb==1 && kb==1){     //如果都沒有數字重複
                        x=99;
                           if(A!= tmpmin && A!= tmpmax){
                          x=A;
                        }
                          if(B!= tmpmin && B!= tmpmax){
                              if(B<x){
                              vpm=x;
                              x=B;
                              y=vpm;
                            }else{
                                if (B==x)
                                   R=1;                 //12組彩
                                y=B;
                            }
                        }
                        if(C!= tmpmin && C!= tmpmax){
                              if(C<x){
                              vpm=x;
                              x=C;
                              y=vpm;
                            }else{
                                if (C==x)
                                   R=1;                //12組彩
                                y=C;
                            }
                        }
                        if(D!= tmpmin && D!= tmpmax){
                              if(D<x){
                              vpm=x;
                              x=D;
                              y=vpm;
                            }else{
                                if (D==x)
                                   R=1;             //12組彩
                                y=D;
                            }
                        }
                    }else{       //如果有數字重複
                         if (sb>=3){
                             x=tmpmin;
                             y=tmpmin;
                             R=3;                     // 4 組彩
                         }else{
                             if (sb==2){
                                x=tmpmin;
                                if(A!= tmpmin && A!= tmpmax)
                                  y=A;
                                if(B!= tmpmin && B!= tmpmax)
                                  y=B;
                                if(C!= tmpmin && C!= tmpmax)
                                  y=C;
                                if(D!= tmpmin && D!= tmpmax)
                                  y=D;
                             }
                         }
                         if (kb==2){
                             y=tmpmax;
                             R++;                            //如果 r=2 則為 6 組彩  r=1則為 12組彩
                             if(A!= tmpmin && A!= tmpmax)
                                x=A;
                            if(B!= tmpmin && B!= tmpmax)
                                x=B;
                            if(C!= tmpmin && C!= tmpmax)
                                x=C;
                            if(D!= tmpmin && D!= tmpmax)
                                x=D;
                         }else{
                             if(kb==3){
                               x=tmpmax;
                               y=tmpmax;
                               R=3;               // 4 組彩
                             }
                         }
                    }
                TTL=w*10*10*10+x*10*10+y*10+z;//將投注號碼轉換成一個各位數字由小排到大的數
                //判斷使用者投注的組彩類型;讓使用者輸入投注倍數
                switch(R){
                    case 3:{//4組彩
                        do{
                            cout << "請輸入投注倍數（每注25元;上限為1350注）：";
                            cin >> M2;
                            if(M2>1350||M2<0){
                                cout << "注數上限為1350注！" <<endl;
                            }
                        }while(M2>1350||M2<0);
                        moneybet+=M2*25;//累積總投注金額
                        break;
                    }
                    case 2:{//6組彩
                        do{
                            cout << "請輸入投注倍數（每注25元;上限為2025注）：";
                            cin >> M3;
                            if(M3>2025||M3<0){
                                cout << "注數上限為2025注！" <<endl;
                            }
                        }while(M3>2025||M3<0);
                        moneybet+=M3*25;//累積總投注金額
                        break;
                    }
                    case 1:{//12組彩
                        do{
                            cout << "請輸入投注倍數（每注25元;上限為4050注）：";
                            cin >> M4;
                            if(M4>4050||M4<0){
                                cout << "注數上限為4050注！" <<endl;
                            }
                        }while(M4>4050||M4<0);
                        moneybet+=M4*25;//累積總投注金額
                        break;
                    }
                    case 0:{//24組彩
                        do{
                            cout << "請輸入投注倍數（每注25元;上限為8100注）：";
                            cin >> M5;
                            if(M5>8100||M5<0){
                                cout << "注數上限為2025注！" <<endl;
                            }
                        }while(M5>8100||M5<0);
                        moneybet+=M5*25;//累積總投注金額
                        break;
                    }
                }
                //判斷該投注號碼中獎與否
                if(ttl==TTL){
                    switch(r){
                        case 3:{
                            moneywin2+=1200*25*M2;
                            break;
                        }
                        case 2:{
                            moneywin3+=800*25*M3;
                            break;
                        }
                        case 1:{
                            moneywin4+=400*25*M4;
                            break;
                        }
                        case 0:{
                            moneywin5+=200*25*M5;
                            break;
                        }
                    }
                }
                break;
            case'3':
                //跳出迴圈
                cout << "=====停止下注=====" <<endl;
                i++;
                continue;
        }
    }
    cout << "總投注金額：" << moneybet <<endl;
    cout << "開獎號碼：" << W <<endl;
    //顯示中獎金額
    if(moneywin1!=0){
        cout <<"正彩贏得：\t" <<  setw(5) << moneywin1 << setw(8) << "元" <<endl;
    }
    if(moneywin2!=0){
        cout <<"4組彩贏得：\t" <<  setw(5) << moneywin2 << setw(8) << "元" <<endl;
    }
    if(moneywin3!=0){
        cout <<"6組彩彩贏得：\t" <<  setw(5) << moneywin3 << setw(8) << "元" <<endl;
    }
    if(moneywin4!=0){
        cout <<"12組彩贏得：\t" <<  setw(5) << moneywin4 << setw(8) << "元" <<endl;
    }
    if(moneywin5!=0){
        cout <<"24組彩贏得：\t" <<  setw(5) << moneywin5 << setw(8) << "元" <<endl;
    }
    moneywin=moneywin1+moneywin2+moneywin3+moneywin4+moneywin5;//計算總中獎金額
    if(moneywin!=0){
        cout << setw(3) << "總獎金為：" << moneywin << "元" <<endl;
    }
    else{
        cout << setw(3) << "銘謝惠顧" <<endl;
    }
    return 0;
}
